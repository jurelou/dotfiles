# Example filepipe configuration.
# Regexes are HCL strings: backslashes are doubled ("\\d" gives \d).

scheduler {
  poll_interval    = "10s"
  workers          = 4
  state_db         = "/var/lib/filepipe/state.db"
  work_dir         = "/var/lib/filepipe/work"
  shutdown_timeout = "5m"
  log_file         = "/var/log/filepipe/filepipe.log"   # also logged to stdout (journald)
}

pipeline "invoices" {
  # "new": at each start, the files already there are ignored.
  start_mode = "new"

  watch {
    paths     = ["/data/inbox"]
    recursive = false
    patterns  = ["^invoice_(?P<client>\\w+)_(?P<date>\\d{8})\\.csv$"]
    settle    = "30s"
  }

  job "validate" {
    plugin = "exec"
    params = {
      command = "/opt/filepipe/scripts/validate.sh"
      args    = ["--client", "{client}", "{path}"]
      timeout = "2m"
      output  = "text"   # stdout stored in data.validate
    }
  }

  job "export" {
    plugin = "copy"
    params = { dest = "/data/export/{client}/{date}" }
  }

  on_success {
    job "notify" {
      plugin = "webhook"
      params = {
        url  = "https://hooks.example.com/invoices"
        body = { file = "{name}", client = "{client}", check = "{data.validate}" }
      }
    }
  }

  on_failure {
    job "alert" {
      plugin = "email"
      params = {
        host         = "smtp.example.com"
        user         = "filepipe"
        password_env = "SMTP_PASSWORD"
        sender       = "filepipe@example.com"
        to           = ["ops@example.com"]
        subject      = "[filepipe] {pipeline}: {failed_job} failed on {name}"
      }
    }

    job "chat" {
      plugin = "mattermost"
      params = {
        webhook_url = "https://mattermost.example.com/hooks/xxxxxxxxxxxxxxxx"
        channel     = "ops-alerts"
        message     = ":warning: **{pipeline}**: `{failed_job}` failed on `{name}`: {error}"
      }
    }
  }
}

pipeline "audit" {
  # "all": at each start, the files already there are processed (unless already done).
  start_mode = "all"

  watch {
    paths    = ["/data/inbox"]
    patterns = ["\\.csv$"]
    settle   = "30s"
  }

  job "trace" {
    plugin = "log"
    params = { message = "received {name}" }
  }
}
