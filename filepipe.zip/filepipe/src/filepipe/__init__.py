"""filepipe: a file pipeline engine."""
