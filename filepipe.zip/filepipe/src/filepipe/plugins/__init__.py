"""Built-in plugins. Importing a module is enough to register its plugin."""

from filepipe.plugins import copy_files, log, mattermost, run_command, send_email, webhook

__all__ = ["copy_files", "log", "mattermost", "run_command", "send_email", "webhook"]
