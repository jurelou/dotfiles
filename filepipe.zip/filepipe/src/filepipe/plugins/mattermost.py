"""Post a message to Mattermost through an incoming webhook.

The webhook URL is the secret: anyone who has it can post. Mattermost does not check any API
key on incoming webhooks; `api_key`, when set, is sent as "Authorization: Bearer <key>", for
example for a reverse proxy in front of Mattermost.
"""

import json
import urllib.request

from filepipe.engine.models import Context, Duration, Item
from filepipe.engine.plugin import Plugin, PluginParams, register


class MattermostParams(PluginParams):
    message: str  # Markdown
    webhook_url: str
    channel: str | None = None  # channel name ("town-square"), default: the webhook's channel
    api_key: str | None = None
    timeout: Duration = 10


@register("mattermost")
class Mattermost(Plugin[MattermostParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        p = self.params
        payload = {"text": p.message}
        if p.channel is not None:
            payload["channel"] = p.channel
        headers = {"Content-Type": "application/json"}
        if p.api_key is not None:
            headers["Authorization"] = f"Bearer {p.api_key}"
        request = urllib.request.Request(
            p.webhook_url, data=json.dumps(payload).encode(), headers=headers, method="POST"
        )
        # An HTTP response >= 400 raises HTTPError: the job fails. The URL is never logged.
        with urllib.request.urlopen(request, timeout=p.timeout) as response:
            ctx.log.info("mattermost message sent: HTTP %d", response.status)
        return item
