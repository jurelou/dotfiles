"""Write a message to the log. Useful to test a chain or to trace a step."""

import logging
from typing import Literal

from filepipe.engine.models import Context, Item
from filepipe.engine.plugin import Plugin, PluginParams, register


class LogParams(PluginParams):
    message: str = "{path}"
    level: Literal["debug", "info", "warning", "error"] = "info"


@register("log")
class Log(Plugin[LogParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        ctx.log.log(logging.getLevelNamesMapping()[self.params.level.upper()], self.params.message)
        return item
