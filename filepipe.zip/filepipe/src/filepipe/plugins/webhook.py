"""Send a JSON object to a URL. Without `body`, the whole Item is sent."""

import json
import urllib.request
from typing import Literal

from pydantic import JsonValue

from filepipe.engine.models import Context, Duration, Item
from filepipe.engine.plugin import Plugin, PluginParams, register


class WebhookParams(PluginParams):
    url: str
    method: Literal["POST", "PUT"] = "POST"
    body: dict[str, JsonValue] | None = None
    headers: dict[str, str] = {}
    timeout: Duration = 10


@register("webhook")
class Webhook(Plugin[WebhookParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        p = self.params
        body = p.body if p.body is not None else item.model_dump(mode="json")
        request = urllib.request.Request(
            p.url,
            data=json.dumps(body).encode(),
            method=p.method,
            headers={"Content-Type": "application/json", **p.headers},
        )
        # An HTTP response >= 400 raises HTTPError: the job fails.
        with urllib.request.urlopen(request, timeout=p.timeout) as response:
            ctx.log.info("%s %s: HTTP %d", p.method, p.url, response.status)
        return item
