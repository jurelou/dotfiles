"""Copy the current files to a directory. The copies become the current files.

A relative `dest` starts from the work directory of the run.
"""

import shutil
from pathlib import Path

from filepipe.engine.models import Context, Item
from filepipe.engine.plugin import Plugin, PluginParams, register


class CopyParams(PluginParams):
    dest: str


@register("copy")
class Copy(Plugin[CopyParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        dest = ctx.workdir / self.params.dest
        dest.mkdir(parents=True, exist_ok=True)
        copied = tuple(Path(shutil.copy2(f, dest / f.name)) for f in item.files)
        ctx.log.info("%d file(s) copied to %s", len(copied), dest)
        return item.model_copy(update={"files": copied})
