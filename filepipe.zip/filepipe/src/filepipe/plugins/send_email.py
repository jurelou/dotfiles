"""Send an email over SMTP. The password comes from an environment variable."""

import os
import smtplib
from email.message import EmailMessage
from typing import Literal

from pydantic import Field

from filepipe.engine.models import Context, Duration, Item
from filepipe.engine.plugin import Plugin, PluginParams, register


class EmailParams(PluginParams):
    host: str
    port: int = 587
    tls: Literal["starttls", "ssl", "none"] = "starttls"
    user: str | None = None
    password_env: str | None = None  # name of the variable that holds the password
    sender: str
    to: list[str] = Field(min_length=1)
    subject: str
    body: str | None = None  # default: pipeline, file and error if any
    timeout: Duration = 30


@register("email")
class Email(Plugin[EmailParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        p = self.params
        message = EmailMessage()
        message["From"] = p.sender
        message["To"] = ", ".join(p.to)
        message["Subject"] = p.subject
        message.set_content(p.body if p.body is not None else _default_body(item, ctx))

        smtp_class = smtplib.SMTP_SSL if p.tls == "ssl" else smtplib.SMTP
        with smtp_class(p.host, p.port, timeout=p.timeout) as smtp:
            if p.tls == "starttls":
                smtp.starttls()
            if p.user is not None:
                smtp.login(p.user, self._password())
            smtp.send_message(message)
        ctx.log.info("email sent to %s", message["To"])
        return item

    def _password(self) -> str:
        name = self.params.password_env
        if name is None:
            raise ValueError("password_env is required when user is set")
        if name not in os.environ:
            raise RuntimeError(f"environment variable {name} is not set")
        return os.environ[name]


def _default_body(item: Item, ctx: Context) -> str:
    lines = [f"Pipeline: {ctx.pipeline}", f"Run: {ctx.run_id}", f"File: {item.source}"]
    if "failed_job" in item.vars:
        lines += [f"Failed job: {item.vars['failed_job']}", f"Error: {item.vars['error']}"]
    return "\n".join(lines) + "\n"
