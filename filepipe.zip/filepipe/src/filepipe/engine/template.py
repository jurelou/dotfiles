"""Rendering of {variable} and {data.key} in the params of the jobs.

Only an identifier between braces is recognized: `\\d{8}` in a regex is left alone.
"""

import json
import re
from collections.abc import Mapping
from typing import Any

from pydantic import JsonValue

_VAR = re.compile(r"\{([A-Za-z_]\w*(?:\.\w+)?)\}")


def render(value: Any, vars: Mapping[str, str], data: Mapping[str, JsonValue]) -> Any:
    """Render every string of `value`, including inside nested lists and objects."""
    if isinstance(value, str):
        return _VAR.sub(lambda m: _lookup(m[1], vars, data), value)
    if isinstance(value, list):
        return [render(v, vars, data) for v in value]
    if isinstance(value, dict):
        return {k: render(v, vars, data) for k, v in value.items()}
    return value


def names(value: Any) -> set[str]:
    """Names of the variables used in `value`."""
    if isinstance(value, str):
        return set(_VAR.findall(value))
    if isinstance(value, dict):
        value = list(value.values())
    if isinstance(value, list):
        return set().union(*(names(v) for v in value))
    return set()


def _lookup(name: str, vars: Mapping[str, str], data: Mapping[str, JsonValue]) -> str:
    if name.startswith("data."):
        key = name.removeprefix("data.")
        if key not in data:
            raise ValueError(f"variable {{{name}}} is missing: no job produced data.{key}")
        value = data[key]
        return value if isinstance(value, str) else json.dumps(value)
    if name not in vars:
        raise ValueError(f"unknown variable {{{name}}}")
    return vars[name]
