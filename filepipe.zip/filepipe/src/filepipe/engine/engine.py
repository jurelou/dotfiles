"""Engine loop: scan, run the ready files in parallel, wait for all of them, scan again."""

import logging
import threading
import time
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor, wait

from filepipe.engine.config import Config
from filepipe.engine.db import State
from filepipe.engine.models import Status
from filepipe.engine.runner import Runner
from filepipe.engine.scanner import Scanner

log = logging.getLogger("filepipe")


class Engine:
    def __init__(
        self, config: Config, state: State, clock: Callable[[], float] = time.monotonic
    ) -> None:
        self._config = config
        self._state = state
        self.stopping = threading.Event()
        self._scanner = Scanner(clock)
        self._runner = Runner(state, config.scheduler.work_dir, self.stopping)
        self._pool = ThreadPoolExecutor(config.scheduler.workers, thread_name_prefix="run")
        self._futures: list[Future[Status]] = []  # runs of the current cycle

    def start(self) -> None:
        """Mark the runs left `running` as interrupted, then apply start_mode."""
        for run in self._state.interrupt_running():
            log.warning(
                "run #%d interrupted (%s, %s, job %s): not restarted, see `filepipe forget`",
                run.id,
                run.pipeline,
                run.path,
                run.job,
            )
        for pipeline in self._config.pipelines:
            for root in pipeline.watch.paths:
                if not root.is_dir():
                    log.warning("pipeline %s: directory not found %s", pipeline.name, root)
            if pipeline.start_mode == "new":
                ignored = self._scanner.ignore_existing(pipeline)
                log.info("pipeline %s: %d existing file(s) ignored", pipeline.name, ignored)

    def cycle(self) -> list[Status]:
        """One scan: run every ready file not yet in the database, then wait for all runs.

        The next scan only starts once the whole cycle is over, so a file can never be picked
        up twice and there is no need to keep track of running runs.
        """
        self._futures = [
            self._pool.submit(self._runner.run, pipeline, version)
            for pipeline, version in self._scanner.scan(self._config.pipelines)
            if not self._state.is_known(pipeline.name, version)
        ]
        pending = set(self._futures)
        while pending and not self.stopping.is_set():
            _, pending = wait(pending, timeout=1)
        statuses = []
        for future in self._futures:
            if not future.done() or future.cancelled():
                continue
            if (exc := future.exception()) is not None:
                log.error("internal error during a run", exc_info=exc)
            else:
                statuses.append(future.result())
        return statuses

    def run_forever(self) -> bool:
        """Run cycles until `stopping` is set. Return False if runs had to be abandoned."""
        self.start()
        while not self.stopping.is_set():
            try:
                self.cycle()
            except Exception:
                log.exception("cycle failed")
            self._sleep(self._config.scheduler.poll_interval)
        return self._shutdown()

    def _sleep(self, seconds: float) -> None:
        """Sleep until the next scan or a stop request.

        Not with stopping.wait(): a signal handler sets `stopping`, and it would deadlock if
        the signal arrived while this thread held the lock of the Event.
        """
        deadline = time.monotonic() + seconds
        while not self.stopping.is_set() and time.monotonic() < deadline:
            time.sleep(0.2)

    def run_once(self) -> list[Status]:
        """A single cycle."""
        self.start()
        statuses = self.cycle()
        self._pool.shutdown()
        return statuses

    def _shutdown(self) -> bool:
        """Cancel the runs not started yet and wait for the others, at most shutdown_timeout."""
        self._pool.shutdown(wait=False, cancel_futures=True)
        running = [f for f in self._futures if not f.done()]
        if running:
            log.info("stopping: waiting for %d run(s)", len(running))
        _, not_done = wait(running, timeout=self._config.scheduler.shutdown_timeout)
        if not_done:
            for run in self._state.interrupt_running():
                log.warning("run #%d interrupted (%s, job %s)", run.id, run.path, run.job)
            return False
        return True
