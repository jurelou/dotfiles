"""Execution of a run: the jobs of one pipeline, in order, for one file."""

import logging
import shutil
import threading
from collections.abc import MutableMapping
from pathlib import Path
from typing import Any

from filepipe.engine import template
from filepipe.engine.config import JobConfig, PipelineConfig
from filepipe.engine.db import State
from filepipe.engine.models import Context, FileVersion, Item, Skip, Status
from filepipe.engine.plugin import get_plugin


class RunLog(logging.LoggerAdapter[logging.Logger]):
    """Prefix every message with the pipeline, the run number and the job."""

    def __init__(self, prefix: str) -> None:
        super().__init__(logging.getLogger("filepipe.run"), {})
        self.prefix = prefix

    def process(
        self, msg: Any, kwargs: MutableMapping[str, Any]
    ) -> tuple[Any, MutableMapping[str, Any]]:
        return f"[{self.prefix}] {msg}", kwargs


class Runner:
    def __init__(self, state: State, work_dir: Path, stopping: threading.Event) -> None:
        self._state = state
        self._work_dir = work_dir
        self._stopping = stopping

    def run(self, pipeline: PipelineConfig, version: FileVersion) -> Status:
        run_id = self._state.start_run(pipeline.name, version)
        workdir = self._work_dir / str(run_id)
        log = RunLog(f"{pipeline.name} #{run_id}")
        log.info("start: %s", version.path)

        item = Item.from_file(version, pipeline.name, run_id)
        status, item, failure = self._run_chain(pipeline, item, run_id, workdir, log)
        self._state.finish_run(run_id, status, failure.get("error"))
        log.info("end: %s", status)

        # A failing hook is only logged: the status of the run is already final.
        if status is Status.SUCCESS:
            self._run_hooks(pipeline, pipeline.on_success, item, run_id, workdir)
        elif status is Status.FAILED:
            item = item.model_copy(update={"vars": {**item.vars, **failure}})
            self._run_hooks(pipeline, pipeline.on_failure, item, run_id, workdir)
        if status in (Status.SUCCESS, Status.SKIPPED):
            shutil.rmtree(workdir, ignore_errors=True)
        return status

    def _run_chain(
        self, pipeline: PipelineConfig, item: Item, run_id: int, workdir: Path, log: RunLog
    ) -> tuple[Status, Item, dict[str, str]]:
        """Run the jobs in order.

        Return the status, the last valid Item and, on failure, the FAILURE_VARS.
        """
        job = pipeline.jobs[0]
        try:
            shutil.rmtree(workdir, ignore_errors=True)  # left over by a reset database
            workdir.mkdir(parents=True)
            for job in pipeline.jobs:
                self._state.set_job(run_id, job.name)
                item = self._run_job(job, item, self._context(pipeline, run_id, job, workdir))
        except Skip as skip:
            log.info("skipped by %s: %s", job.name, skip)
            return Status.SKIPPED, item, {}
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            log.error("%s failed: %s", job.name, error, exc_info=log.isEnabledFor(logging.DEBUG))
            status = Status.INTERRUPTED if self._stopping.is_set() else Status.FAILED
            return status, item, {"failed_job": job.name, "error": error}
        return Status.SUCCESS, item, {}

    def _run_hooks(
        self,
        pipeline: PipelineConfig,
        jobs: list[JobConfig],
        item: Item,
        run_id: int,
        workdir: Path,
    ) -> None:
        """Run the hooks in order. A failing hook does not prevent the next ones."""
        for job in jobs:
            ctx = self._context(pipeline, run_id, job, workdir)
            try:
                item = self._run_job(job, item, ctx)
            except Skip:
                break
            except Exception as exc:
                ctx.log.error("hook failed: %s: %s", type(exc).__name__, exc)

    def _run_job(self, job: JobConfig, item: Item, ctx: Context) -> Item:
        plugin = get_plugin(job.plugin)
        raw = plugin.Params.model_validate(job.params).model_dump()  # with the default values
        params = plugin.Params.model_validate(template.render(raw, item.vars, item.data))
        result = plugin(params).run(item, ctx)
        if not isinstance(result, Item):
            raise TypeError(f"{job.plugin} must return an Item, not {type(result).__name__}")
        return Item.model_validate(dict(result))  # validate again: data must stay JSON

    def _context(
        self, pipeline: PipelineConfig, run_id: int, job: JobConfig, workdir: Path
    ) -> Context:
        return Context(
            run_id=run_id,
            pipeline=pipeline.name,
            job=job.name,
            workdir=workdir,
            log=RunLog(f"{pipeline.name} #{run_id} {job.name}"),
            stopping=self._stopping,
        )
