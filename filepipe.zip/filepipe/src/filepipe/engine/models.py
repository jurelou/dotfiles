"""Data exchanged between the engine and the plugins."""

import logging
import re
import threading
from enum import StrEnum
from pathlib import Path
from typing import Annotated, Self

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, JsonValue

# Variables always available in templates, on top of the named groups of the regexes.
# Item.from_file() sets them.
BUILTIN_VARS = frozenset({"path", "name", "stem", "suffix", "dir", "pipeline", "run_id"})
# Variables added for the jobs of on_failure.
FAILURE_VARS = frozenset({"failed_job", "error"})

_DURATION = re.compile(r"(\d+(?:\.\d+)?)\s*(ms|s|m|h|d)")
_UNITS = {"ms": 0.001, "s": 1, "m": 60, "h": 3600, "d": 86400}


def _parse_duration(value: object) -> object:
    """Convert "30s", "5m", "2h"... to seconds. A number is already in seconds."""
    if isinstance(value, str):
        match = _DURATION.fullmatch(value.strip())
        if match is None:
            raise ValueError(f"invalid duration {value!r} (examples: '30s', '5m', '2h')")
        return float(match[1]) * _UNITS[match[2]]
    return value


Duration = Annotated[float, BeforeValidator(_parse_duration), Field(ge=0)]


class Status(StrEnum):
    """Status of a run, stored as text in the database."""

    RUNNING = "running"
    SUCCESS = "success"  # every job succeeded
    SKIPPED = "skipped"  # a job raised Skip
    FAILED = "failed"  # a job raised another exception
    INTERRUPTED = "interrupted"  # the daemon stopped or crashed during the run


class Skip(Exception):
    """Raised by a job to stop the chain normally (status SKIPPED)."""


class FileVersion(BaseModel):
    """A file that matches a pipeline, as it is at scan time."""

    model_config = ConfigDict(frozen=True)

    path: Path
    size: int
    mtime_ns: int
    groups: dict[str, str]  # named groups of the regex that matched


class Item(BaseModel):
    """What flows from job to job. Each job returns a new Item."""

    model_config = ConfigDict(frozen=True)

    source: Path  # original file, never modified
    files: tuple[Path, ...]  # current files, initially (source,)
    vars: dict[str, str]  # regex groups + BUILTIN_VARS
    data: dict[str, JsonValue] = {}  # metadata enriched from job to job

    @classmethod
    def from_file(cls, version: FileVersion, pipeline: str, run_id: int) -> Self:
        """First Item of a run: the source file, its regex groups and BUILTIN_VARS."""
        path = version.path
        builtins = {
            "path": str(path),
            "name": path.name,
            "stem": path.stem,
            "suffix": path.suffix,
            "dir": str(path.parent),
            "pipeline": pipeline,
            "run_id": str(run_id),
        }
        return cls(source=path, files=(path,), vars={**version.groups, **builtins})


class Context(BaseModel):
    """Execution context of a job."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    run_id: int
    pipeline: str
    job: str
    workdir: Path  # directory dedicated to the run
    log: logging.LoggerAdapter[logging.Logger]
    stopping: threading.Event  # set when the daemon is asked to stop
