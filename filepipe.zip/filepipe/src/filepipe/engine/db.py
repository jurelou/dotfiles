"""Persistent state in SQLite: the only memory of the daemon that matters."""

import sqlite3
import threading
from collections.abc import Iterable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Self

from pydantic import BaseModel, ConfigDict

from filepipe.engine.models import FileVersion, Status

SCHEMA_VERSION = 1
_SCHEMA = """
CREATE TABLE runs (
    id          INTEGER PRIMARY KEY,
    pipeline    TEXT NOT NULL,
    path        TEXT NOT NULL,
    size        INTEGER NOT NULL,
    mtime_ns    INTEGER NOT NULL,
    status      TEXT NOT NULL,
    job         TEXT,
    error       TEXT,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    UNIQUE (pipeline, path, size, mtime_ns)
);
CREATE INDEX runs_by_status ON runs (status);
"""


class RunRecord(BaseModel):
    model_config = ConfigDict(frozen=True)

    id: int
    pipeline: str
    path: Path
    size: int
    mtime_ns: int
    status: Status
    job: str | None
    error: str | None
    started_at: datetime
    finished_at: datetime | None


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class State:
    """Database access. A single connection, guarded by a lock, shared by the threads."""

    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(path, check_same_thread=False, timeout=30)
        self._db.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        self._db.execute("PRAGMA journal_mode=WAL")
        version = self._db.execute("PRAGMA user_version").fetchone()[0]
        if version == 0:
            self._db.executescript(_SCHEMA + f"PRAGMA user_version = {SCHEMA_VERSION};")
        elif version != SCHEMA_VERSION:
            raise RuntimeError(f"{path}: unknown schema version {version}")

    def close(self) -> None:
        self._db.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    def _write(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
        with self._lock, self._db:
            return self._db.execute(sql, tuple(params))

    def _read(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._db.execute(sql, tuple(params)).fetchall()

    def is_known(self, pipeline: str, version: FileVersion) -> bool:
        rows = self._read(
            "SELECT 1 FROM runs WHERE pipeline = ? AND path = ? AND size = ? AND mtime_ns = ?",
            (pipeline, str(version.path), version.size, version.mtime_ns),
        )
        return bool(rows)

    def start_run(self, pipeline: str, version: FileVersion) -> int:
        cursor = self._write(
            "INSERT INTO runs (pipeline, path, size, mtime_ns, status, started_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (pipeline, str(version.path), version.size, version.mtime_ns, Status.RUNNING, _now()),
        )
        assert cursor.lastrowid is not None
        return cursor.lastrowid

    def set_job(self, run_id: int, job: str) -> None:
        self._write("UPDATE runs SET job = ? WHERE id = ?", (job, run_id))

    def finish_run(self, run_id: int, status: Status, error: str | None = None) -> None:
        self._write(
            "UPDATE runs SET status = ?, error = ?, finished_at = ? WHERE id = ?",
            (status, error, _now(), run_id),
        )

    def interrupt_running(self) -> list[RunRecord]:
        """Mark RUNNING runs as INTERRUPTED. They are never restarted."""
        runs = self.runs(status=Status.RUNNING)
        self._write(
            "UPDATE runs SET status = ?, finished_at = ? WHERE status = ?",
            (Status.INTERRUPTED, _now(), Status.RUNNING),
        )
        return runs

    def runs(
        self, pipeline: str | None = None, status: Status | None = None, path: str | None = None
    ) -> list[RunRecord]:
        where, params = _filters(pipeline, status, path)
        rows = self._read(f"SELECT * FROM runs WHERE {where} ORDER BY id", params)
        return [RunRecord.model_validate(dict(row)) for row in rows]

    def counts(self) -> list[tuple[str, Status, int]]:
        rows = self._read(
            "SELECT pipeline, status, COUNT(*) AS n FROM runs"
            " GROUP BY pipeline, status ORDER BY pipeline, status"
        )
        return [(row["pipeline"], Status(row["status"]), row["n"]) for row in rows]

    def forget(
        self, pipeline: str | None = None, status: Status | None = None, path: str | None = None
    ) -> list[RunRecord]:
        """Delete finished runs: their files will be processed again at the next scan."""
        where, params = _filters(pipeline, status, path)
        where += " AND status != ?"
        params.append(Status.RUNNING)
        with self._lock, self._db:
            rows = self._db.execute(f"SELECT * FROM runs WHERE {where}", params).fetchall()
            self._db.execute(f"DELETE FROM runs WHERE {where}", params)
        return [RunRecord.model_validate(dict(row)) for row in rows]


def _filters(
    pipeline: str | None, status: Status | None, path: str | None
) -> tuple[str, list[str]]:
    clauses, params = ["1 = 1"], []
    for clause, value in (
        ("pipeline = ?", pipeline),
        ("status = ?", status),
        ("path GLOB ?", path),
    ):
        if value is not None:
            clauses.append(clause)
            params.append(value)
    return " AND ".join(clauses), params
