"""File discovery: regex matching, files ignored by start_mode and stability."""

import logging
import stat
import time
from collections.abc import Callable, Iterator, Sequence
from pathlib import Path

from pydantic import BaseModel, ConfigDict

from filepipe.engine.config import PipelineConfig, WatchConfig
from filepipe.engine.models import FileVersion

log = logging.getLogger("filepipe")


class Observation(BaseModel):
    """Last state seen of a file, and since when it has not changed."""

    model_config = ConfigDict(frozen=True)

    size: int
    mtime_ns: int
    since: float


def match_files(watch: WatchConfig) -> Iterator[FileVersion]:
    """Files that match a pattern, stable or not, each one once even if paths overlap."""
    found: set[Path] = set()
    for root in watch.paths:
        candidates = root.rglob("*") if watch.recursive else root.glob("*")
        for path in sorted(candidates):
            if path in found:
                continue
            relative = path.relative_to(root).as_posix()
            match = next((m for p in watch.patterns if (m := p.search(relative))), None)
            if match is None:
                continue
            try:
                st = path.stat()
            except FileNotFoundError:  # deleted between the listing and the stat
                continue
            if stat.S_ISREG(st.st_mode):
                found.add(path)
                groups = {k: v or "" for k, v in match.groupdict().items()}
                yield FileVersion(
                    path=path, size=st.st_size, mtime_ns=st.st_mtime_ns, groups=groups
                )


def _key(pipeline: str, version: FileVersion) -> tuple[str, Path, int, int]:
    return pipeline, version.path, version.size, version.mtime_ns


class Scanner:
    """Decides which files are candidates for a run.

    Its state lives in memory only: the files ignored by start_mode = "new", and the last
    state of every file to apply `settle` (after a restart, we simply wait for it again).
    """

    def __init__(self, clock: Callable[[], float] = time.monotonic) -> None:
        self._clock = clock
        self._seen: dict[Path, Observation] = {}
        self._ignored: set[tuple[str, Path, int, int]] = set()
        self._invalid_names: set[Path] = set()  # already reported

    def ignore_existing(self, pipeline: PipelineConfig) -> int:
        """Ignore the files already there, until they change. Return how many."""
        ignored = {_key(pipeline.name, v) for v in match_files(pipeline.watch)}
        self._ignored |= ignored
        return len(ignored)

    def scan(self, pipelines: Sequence[PipelineConfig]) -> list[tuple[PipelineConfig, FileVersion]]:
        """Ready (pipeline, file) pairs: not ignored, and unchanged for at least `settle`."""
        now = self._clock()
        seen: dict[Path, Observation] = {}
        ready = []
        for pipeline in pipelines:
            for version in match_files(pipeline.watch):
                if _key(pipeline.name, version) in self._ignored:
                    continue
                if not self._valid_name(version.path):
                    continue
                obs = seen.get(version.path) or self._observe(version, now)
                seen[version.path] = obs
                if now - obs.since >= pipeline.watch.settle:
                    ready.append((pipeline, version))
        self._seen = seen  # files that disappeared are forgotten
        ready.sort(key=lambda pair: (pair[1].mtime_ns, str(pair[1].path)))
        return ready

    def _valid_name(self, path: Path) -> bool:
        """A name that is not valid UTF-8 cannot be stored: skip the file, say it once."""
        try:
            str(path).encode()
        except UnicodeEncodeError:
            if path not in self._invalid_names:
                self._invalid_names.add(path)
                log.warning("ignored, the file name is not valid UTF-8: %r", path)
            return False
        return True

    def _observe(self, version: FileVersion, now: float) -> Observation:
        old = self._seen.get(version.path)
        if old is not None and (old.size, old.mtime_ns) == (version.size, version.mtime_ns):
            return old
        return Observation(size=version.size, mtime_ns=version.mtime_ns, since=now)
