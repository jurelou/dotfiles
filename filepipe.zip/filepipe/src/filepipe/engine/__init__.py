"""Engine: configuration, scanning, state and execution of the pipelines."""
