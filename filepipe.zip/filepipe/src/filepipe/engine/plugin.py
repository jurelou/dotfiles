"""Plugin base class and registry."""

import importlib
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any, ClassVar, Generic, TypeVar, get_args

from pydantic import BaseModel, ConfigDict

from filepipe.engine.models import Context, Item


class PluginParams(BaseModel):
    """Base class of the params of a plugin: an unknown key is an error."""

    model_config = ConfigDict(extra="forbid", frozen=True)


P = TypeVar("P", bound=PluginParams)
T = TypeVar("T", bound="type[Plugin[Any]]")


class Plugin(ABC, Generic[P]):
    """A job: receives an Item, returns a new Item.

    A new instance is created for every execution, with its params already rendered.
    The params model is the generic argument: `class Copy(Plugin[CopyParams])`.
    """

    Params: ClassVar[type[PluginParams]] = PluginParams

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        for base in getattr(cls, "__orig_bases__", ()):
            for arg in get_args(base):
                if isinstance(arg, type) and issubclass(arg, PluginParams):
                    cls.Params = arg

    def __init__(self, params: P) -> None:
        self.params = params

    @abstractmethod
    def run(self, item: Item, ctx: Context) -> Item: ...


_REGISTRY: dict[str, type[Plugin[Any]]] = {}


def register(name: str) -> Callable[[T], T]:
    """Decorator that registers a plugin under `name`."""

    def decorator(cls: T) -> T:
        if name in _REGISTRY:
            raise ValueError(f"plugin {name!r} is already registered")
        _REGISTRY[name] = cls
        return cls

    return decorator


def get_plugin(name: str) -> type[Plugin[Any]]:
    importlib.import_module("filepipe.plugins")  # registers the built-in plugins
    try:
        return _REGISTRY[name]
    except KeyError:
        known = ", ".join(sorted(_REGISTRY))
        raise ValueError(f"unknown plugin {name!r} (available: {known})") from None
