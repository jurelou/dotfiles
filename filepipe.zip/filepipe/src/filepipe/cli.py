"""Command line: validate, run, run-once, status, forget."""

import logging
import os
import shutil
import signal
import sys
from collections import Counter
from logging.handlers import RotatingFileHandler
from pathlib import Path

import click

from filepipe.engine.config import Config, ConfigError, load_config
from filepipe.engine.db import State
from filepipe.engine.engine import Engine
from filepipe.engine.models import Status

DEFAULT_CONFIG = Path("/etc/filepipe/config.hcl")
LOG_FILE_MAX_BYTES = 10 * 1024 * 1024  # then the file is rotated...
LOG_FILE_BACKUPS = 5  # ...keeping filepipe.log.1 to filepipe.log.5
FORGETTABLE = [s.value for s in Status if s is not Status.RUNNING]


@click.group()
@click.option(
    "-c",
    "--config",
    "config_path",
    type=click.Path(path_type=Path, dir_okay=False),
    default=DEFAULT_CONFIG,
    envvar="FILEPIPE_CONFIG",
    show_default=True,
    help="HCL configuration file.",
)
@click.option(
    "--log-level",
    type=click.Choice(["debug", "info", "warning", "error"], case_sensitive=False),
    default="info",
    show_default=True,
)
@click.pass_context
def main(ctx: click.Context, config_path: Path, log_level: str) -> None:
    """File pipeline engine."""
    # No timestamp: journald already adds one.
    logging.basicConfig(
        level=log_level.upper(),
        format="%(levelname)s %(message)s",
        stream=sys.stdout,
        force=True,
    )
    ctx.obj = config_path


def _load(config_path: Path) -> Config:
    try:
        return load_config(config_path)
    except ConfigError as exc:
        raise click.ClickException(str(exc)) from None


def _log_to_file(config: Config) -> None:
    """Also write the logs to `log_file`, with timestamps, rotating it when it grows."""
    path = config.scheduler.log_file
    if path is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(
            path, maxBytes=LOG_FILE_MAX_BYTES, backupCount=LOG_FILE_BACKUPS, encoding="utf-8"
        )
    except OSError as exc:
        raise click.ClickException(f"cannot open the log file {path}: {exc.strerror}") from None
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logging.getLogger().addHandler(handler)


@main.command()
@click.pass_obj
def validate(config_path: Path) -> None:
    """Validate the configuration without running anything."""
    config = _load(config_path)
    for pipeline in config.pipelines:
        jobs = " -> ".join(job.name for job in pipeline.jobs)
        click.echo(f"{pipeline.name} ({pipeline.start_mode}): {jobs}")
    click.echo(f"OK: {len(config.pipelines)} pipeline(s)")


@main.command()
@click.pass_obj
def run(config_path: Path) -> None:
    """Start the daemon (used by systemd)."""
    config = _load(config_path)
    _log_to_file(config)
    with State(config.scheduler.state_db) as state:
        engine = Engine(config, state)
        for sig in (signal.SIGTERM, signal.SIGINT):
            signal.signal(sig, lambda *_: engine.stopping.set())
        logging.getLogger("filepipe").info("starting: %d pipeline(s)", len(config.pipelines))
        if not engine.run_forever():
            # Runs are still going: exit now, without waiting for their threads.
            logging.shutdown()
            os._exit(1)
    logging.getLogger("filepipe").info("stopped")


@main.command("run-once")
@click.pass_obj
def run_once(config_path: Path) -> None:
    """Scan once, process the ready files, then exit."""
    config = _load(config_path)
    _log_to_file(config)
    with State(config.scheduler.state_db) as state:
        statuses = Engine(config, state).run_once()
    summary = ", ".join(f"{n} {status}" for status, n in sorted(Counter(statuses).items()))
    click.echo(f"{len(statuses)} run(s)" + (f": {summary}" if summary else ""))
    if Status.FAILED in statuses:
        sys.exit(1)


@main.command()
@click.pass_obj
def status(config_path: Path) -> None:
    """Number of runs per pipeline and status, then the runs that need attention."""
    config = _load(config_path)
    with State(config.scheduler.state_db) as state:
        counts = state.counts()
        to_check = state.runs(status=Status.FAILED) + state.runs(status=Status.INTERRUPTED)
    for pipeline, run_status, n in counts:
        click.echo(f"{pipeline:<20} {run_status:<12} {n}")
    for r in to_check:
        click.echo(f"#{r.id} {r.status} {r.pipeline} {r.path} job={r.job} {r.error or ''}")


@main.command()
@click.option("--pipeline", help="Pipeline name.")
@click.option("--status", "run_status", type=click.Choice(FORGETTABLE), help="Run status.")
@click.option("--path", help="Path pattern, for example '/data/inbox/invoice_*'.")
@click.pass_obj
def forget(
    config_path: Path, pipeline: str | None, run_status: str | None, path: str | None
) -> None:
    """Forget runs: their files will be processed again at the next scan."""
    if pipeline is None and run_status is None and path is None:
        raise click.UsageError("give at least --pipeline, --status or --path")
    config = _load(config_path)
    status_filter = Status(run_status) if run_status is not None else None
    with State(config.scheduler.state_db) as state:
        forgotten = state.forget(pipeline, status_filter, path)
    for run in forgotten:
        shutil.rmtree(config.scheduler.work_dir / str(run.id), ignore_errors=True)
    click.echo(f"{len(forgotten)} run(s) forgotten")
