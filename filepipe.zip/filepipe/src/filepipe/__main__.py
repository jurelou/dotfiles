from filepipe.cli import main

main()
