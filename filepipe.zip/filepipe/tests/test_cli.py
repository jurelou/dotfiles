import logging
from collections.abc import Callable, Iterator
from logging.handlers import RotatingFileHandler
from pathlib import Path

import pytest
from click.testing import CliRunner
from conftest import pipeline

from filepipe.cli import main

EXAMPLE = Path(__file__).parents[1] / "examples" / "config.hcl"


def _cli(*args: str) -> tuple[int, str]:
    result = CliRunner().invoke(main, list(args))
    return result.exit_code, result.output


def test_validate_example() -> None:
    code, output = _cli("-c", str(EXAMPLE), "validate")
    assert code == 0
    assert "invoices (new): validate -> export" in output
    assert "OK: 2 pipeline(s)" in output


def test_validate_reports_the_faulty_key(write_config: Callable[..., Path]) -> None:
    config = write_config(pipeline(jobs='job "j" {\n plugin = "log"\n retries = 2\n}'))
    code, output = _cli("-c", str(config), "validate")
    assert code == 1
    assert "pipelines.p.jobs.j.retries: Extra inputs are not permitted" in output


def test_run_once_status_forget(write_config: Callable[..., Path], inbox: Path) -> None:
    jobs = 'job "ok" { plugin = "log" }'
    failing = 'job "ko" { plugin = "test_fail" }'
    config = str(write_config(pipeline("good", jobs=jobs), pipeline("bad", jobs=failing)))
    (inbox / "a.csv").write_text("x")

    code, output = _cli("-c", config, "run-once")
    assert code == 1
    assert "2 run(s): 1 failed, 1 success" in output

    code, output = _cli("-c", config, "status")
    assert code == 0
    assert "job=ko RuntimeError: boom" in output

    assert _cli("-c", config, "forget")[0] == 2  # at least one filter
    assert "1 run(s) forgotten" in _cli("-c", config, "forget", "--status", "failed")[1]
    assert "1 run(s): 1 failed" in _cli("-c", config, "run-once")[1]


@pytest.fixture
def _close_log_files() -> Iterator[None]:
    yield
    root = logging.getLogger()
    for handler in [h for h in root.handlers if isinstance(h, RotatingFileHandler)]:
        root.removeHandler(handler)
        handler.close()


@pytest.mark.usefixtures("_close_log_files")
def test_logs_go_to_stdout_and_to_the_log_file(
    write_config: Callable[..., Path], inbox: Path, tmp_path: Path
) -> None:
    config = write_config(
        pipeline(jobs='job "j" { plugin = "log" }'), scheduler='log_file = "logs/run.log"'
    )
    (inbox / "a.csv").write_text("x")

    code, output = _cli("-c", str(config), "run-once")

    assert code == 0
    line = f"[p #1 j] {inbox / 'a.csv'}"
    assert line in output
    logged = (tmp_path / "logs" / "run.log").read_text()
    assert line in logged
    assert logged[:4].isdigit()  # each line starts with a timestamp


def test_unusable_log_file_is_a_clear_error(
    write_config: Callable[..., Path], tmp_path: Path
) -> None:
    (tmp_path / "not_a_dir").write_text("")
    config = write_config(pipeline(), scheduler='log_file = "not_a_dir/run.log"')
    code, output = _cli("-c", str(config), "run-once")
    assert code == 1
    assert "cannot open the log file" in output
