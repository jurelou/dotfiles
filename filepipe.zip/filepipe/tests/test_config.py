from collections.abc import Callable
from pathlib import Path

import pytest
from conftest import pipeline

from filepipe.engine.config import Config, ConfigError, load_config

EXAMPLE = Path(__file__).parents[1] / "examples" / "config.hcl"


def test_example_config_is_valid() -> None:
    config = load_config(EXAMPLE)
    invoices, audit = config.pipelines
    assert invoices.start_mode == "new"
    assert invoices.watch.patterns[0].pattern == r"^invoice_(?P<client>\w+)_(?P<date>\d{8})\.csv$"
    assert invoices.watch.settle == 30
    assert [j.name for j in invoices.jobs] == ["validate", "export"]
    assert invoices.jobs[0].params["args"] == ["--client", "{client}", "{path}"]
    assert invoices.on_success[0].params["body"]["client"] == "{client}"
    assert [j.plugin for j in invoices.on_failure] == ["email", "mattermost"]
    assert config.scheduler.shutdown_timeout == 300
    assert audit.watch.patterns[0].search("invoice_acme_20261015.csv")


def test_relative_paths_start_from_the_config_dir(make_config: Callable[..., Config]) -> None:
    config = make_config(pipeline())
    assert config.scheduler.state_db.is_absolute()
    assert config.pipelines[0].watch.paths[0].name == "inbox"
    assert config.pipelines[0].watch.paths[0].is_absolute()


@pytest.mark.parametrize(
    ("value", "seconds"), [("500ms", 0.5), ("30s", 30), ("5m", 300), ("2h", 7200), ("1d", 86400)]
)
def test_durations(make_config: Callable[..., Config], value: str, seconds: float) -> None:
    config = make_config(pipeline(settle=value))
    assert config.pipelines[0].watch.settle == seconds


def _error(write_config: Callable[..., Path], *pipelines: str) -> str:
    with pytest.raises(ConfigError) as exc:
        load_config(write_config(*pipelines))
    return str(exc.value)


@pytest.mark.parametrize(
    ("block", "expected"),
    [
        ('job "j" {\n plugin = "log"\n retries = 2\n}', "pipelines.p.jobs.j.retries"),
        ('job "j" { plugin = "nope" }', "unknown plugin 'nope'"),
        ('job "j" { plugin = "copy" }', "invalid params for copy: dest: Field required"),
        ('job "j" {\n plugin = "log"\n params = { message = "{client}" }\n}', "['client']"),
        ('job "j" {\n plugin = "log"\n params = { message = "{error}" }\n}', "['error']"),
        ('job "a" { plugin = "log" }\njob "a" { plugin = "log" }', "duplicate job names"),
    ],
)
def test_invalid_jobs(write_config: Callable[..., Path], block: str, expected: str) -> None:
    assert expected in _error(write_config, pipeline(jobs=block))


def test_invalid_duration(write_config: Callable[..., Path]) -> None:
    assert "invalid duration '5 minutes'" in _error(write_config, pipeline(settle="5 minutes"))


def test_invalid_regex(write_config: Callable[..., Path]) -> None:
    assert "pipelines.p.watch.patterns.0" in _error(write_config, pipeline(pattern="(unclosed"))


def test_start_mode_is_required(write_config: Callable[..., Path]) -> None:
    hcl = pipeline().replace('start_mode = "all"', "")
    assert "pipelines.p.start_mode: Field required" in _error(write_config, hcl)


def test_duplicate_pipelines(write_config: Callable[..., Path]) -> None:
    assert "duplicate pipeline names" in _error(write_config, pipeline(), pipeline())


def test_template_variables(make_config: Callable[..., Config]) -> None:
    jobs = """
    job "j" {
      plugin = "log"
      params = { message = "{client} {name} {data.anything}" }
    }"""
    failure = """
    on_failure {
      job "alert" {
        plugin = "log"
        params = { message = "{failed_job} : {error}" }
      }
    }"""
    make_config(pipeline(jobs=jobs, pattern="(?P<client>\\\\w+)\\\\.csv$", extra=failure))


def test_group_must_exist_in_every_pattern(write_config: Callable[..., Path]) -> None:
    hcl = pipeline(
        jobs='job "j" {\n plugin = "log"\n params = { message = "{client}" }\n}',
        pattern='(?P<client>\\\\w+)\\\\.csv$", "\\\\.txt$',
    )
    assert "['client']" in _error(write_config, hcl)


def test_syntax_error(write_config: Callable[..., Path]) -> None:
    assert "invalid HCL syntax" in _error(write_config, "pipeline {")
