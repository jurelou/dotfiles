import threading
import urllib.error
from collections.abc import Callable
from pathlib import Path

import pytest
from conftest import RecordingServer, pipeline

from filepipe.engine.config import Config
from filepipe.engine.db import State
from filepipe.engine.models import Context, Item, Status
from filepipe.engine.runner import Runner
from filepipe.engine.scanner import match_files
from filepipe.plugins.mattermost import Mattermost, MattermostParams


def test_posts_message_to_channel_with_api_key(
    item: Item, ctx: Context, http_server: RecordingServer
) -> None:
    params = MattermostParams(
        message="**done**",
        webhook_url=f"{http_server.url}/hooks/abc123",
        channel="ops-alerts",
        api_key="secret",
    )
    assert Mattermost(params).run(item, ctx) == item

    [(path, headers, body)] = http_server.requests
    assert path == "/hooks/abc123"
    assert body == {"text": "**done**", "channel": "ops-alerts"}
    assert headers["Authorization"] == "Bearer secret"
    assert headers["Content-Type"] == "application/json"


def test_channel_and_api_key_are_optional(
    item: Item, ctx: Context, http_server: RecordingServer
) -> None:
    params = MattermostParams(message="hello", webhook_url=f"{http_server.url}/hooks/abc123")
    Mattermost(params).run(item, ctx)

    [(_, headers, body)] = http_server.requests
    assert body == {"text": "hello"}
    assert "Authorization" not in headers


def test_http_error_fails_the_job(item: Item, ctx: Context, http_server: RecordingServer) -> None:
    http_server.status = 500
    params = MattermostParams(message="hello", webhook_url=f"{http_server.url}/hooks/abc123")
    with pytest.raises(urllib.error.HTTPError):
        Mattermost(params).run(item, ctx)


def test_message_is_rendered_in_a_pipeline(
    make_config: Callable[..., Config], inbox: Path, http_server: RecordingServer
) -> None:
    jobs = f"""
    job "notify" {{
      plugin = "mattermost"
      params = {{
        message     = "{{name}} processed by {{pipeline}}"
        webhook_url = "{http_server.url}/hooks/abc123"
        channel     = "ops"
      }}
    }}"""
    config = make_config(pipeline(jobs=jobs))
    (inbox / "a.csv").write_text("x")
    p = config.pipelines[0]
    with State(config.scheduler.state_db) as state:
        runner = Runner(state, config.scheduler.work_dir, threading.Event())
        assert runner.run(p, next(match_files(p.watch))) == Status.SUCCESS

    [(_, _, body)] = http_server.requests
    assert body == {"text": "a.csv processed by p", "channel": "ops"}
