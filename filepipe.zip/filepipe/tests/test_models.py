from pathlib import Path

from conftest import Record, SetData, SetParams

from filepipe.engine.models import BUILTIN_VARS, FileVersion, Item
from filepipe.engine.plugin import PluginParams
from filepipe.plugins.copy_files import Copy, CopyParams


def test_from_file_sets_every_builtin_var(tmp_path: Path) -> None:
    path = tmp_path / "invoice_acme.csv"
    version = FileVersion(path=path, size=3, mtime_ns=1, groups={"client": "acme"})
    item = Item.from_file(version, "invoices", 7)
    assert set(item.vars) == BUILTIN_VARS | {"client"}
    assert item.vars["stem"] == "invoice_acme"
    assert item.vars["run_id"] == "7"
    assert item.files == (path,)


def test_params_come_from_the_generic_argument() -> None:
    assert Copy.Params is CopyParams
    assert SetData.Params is SetParams
    assert Record.Params is PluginParams
