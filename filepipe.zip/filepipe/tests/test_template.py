import pytest
from pydantic import JsonValue

from filepipe.engine.template import names, render

VARS = {"client": "acme", "name": "f.csv"}
DATA: dict[str, JsonValue] = {"lines": 42, "label": "ok"}


def test_render_nested_values() -> None:
    value = {"a": "{client}/{name}", "b": ["{data.label}", 3], "c": {"d": "{data.lines}"}}
    assert render(value, VARS, DATA) == {"a": "acme/f.csv", "b": ["ok", 3], "c": {"d": "42"}}


def test_regex_braces_are_left_alone() -> None:
    assert render(r"^\d{8}_{client}$", VARS, DATA) == r"^\d{8}_acme$"


@pytest.mark.parametrize("text", ["{missing}", "{data.missing}"])
def test_unknown_variable(text: str) -> None:
    with pytest.raises(ValueError, match="variable"):
        render(text, VARS, DATA)


def test_names() -> None:
    assert names({"a": ["{x} {data.y}", 1], "b": r"\d{2}"}) == {"x", "data.y"}
