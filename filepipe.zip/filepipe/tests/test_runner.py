import logging
import threading
from collections.abc import Callable
from pathlib import Path

import pytest
from conftest import RECORDED, pipeline

from filepipe.engine.config import Config
from filepipe.engine.db import State
from filepipe.engine.models import Status
from filepipe.engine.runner import Runner
from filepipe.engine.scanner import match_files


def _run(config: Config, inbox: Path, name: str = "invoice_acme.csv") -> tuple[Status, State]:
    (inbox / name).write_text("a;b\n")
    state = State(config.scheduler.state_db)
    p = config.pipelines[0]
    version = next(match_files(p.watch))
    status = Runner(state, config.scheduler.work_dir, threading.Event()).run(p, version)
    return status, state


def test_jobs_run_in_order_and_pass_their_output(
    make_config: Callable[..., Config], inbox: Path, tmp_path: Path
) -> None:
    jobs = f"""
    job "set" {{
      plugin = "test_set"
      params = {{ key = "client", value = "{{client}}" }}
    }}
    job "export" {{
      plugin = "copy"
      params = {{ dest = "{tmp_path}/out/{{data.client}}" }}
    }}
    job "check" {{ plugin = "test_record" }}"""
    hooks = 'on_success {\n job "done" { plugin = "test_record" }\n}'
    config = make_config(pipeline(jobs=jobs, pattern="_(?P<client>\\\\w+)\\\\.csv$", extra=hooks))

    status, state = _run(config, inbox)

    assert status == Status.SUCCESS
    copied = tmp_path / "out" / "acme" / "invoice_acme.csv"
    assert copied.read_text() == "a;b\n"
    assert [job for job, _ in RECORDED] == ["check", "done"]
    item = RECORDED[0][1]
    assert item.files == (copied,)
    assert item.data == {"client": "acme"}
    assert item.vars["client"] == "acme"
    assert item.vars["name"] == "invoice_acme.csv"
    assert item.source == inbox / "invoice_acme.csv"
    [run] = state.runs()
    assert (run.status, run.job, run.error) == (Status.SUCCESS, "check", None)
    assert not (config.scheduler.work_dir / str(run.id)).exists()


def test_skip_stops_the_chain_without_hooks(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    jobs = 'job "skip" { plugin = "test_skip" }\njob "after" { plugin = "test_record" }'
    hooks = """
    on_success {
      job "ok" { plugin = "test_record" }
    }
    on_failure {
      job "ko" { plugin = "test_record" }
    }"""
    status, state = _run(make_config(pipeline(jobs=jobs, extra=hooks)), inbox)
    assert status == Status.SKIPPED
    assert RECORDED == []
    assert state.runs()[0].status == Status.SKIPPED


def test_failure_runs_on_failure_with_error_vars(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    jobs = 'job "boom" { plugin = "test_fail" }\njob "after" { plugin = "test_record" }'
    hooks = """
    on_success {
      job "ok" { plugin = "test_record" }
    }
    on_failure {
      job "broken" { plugin = "test_fail" }
      job "ko" { plugin = "test_record" }
    }"""
    config = make_config(pipeline(jobs=jobs, extra=hooks))
    status, state = _run(config, inbox)

    assert status == Status.FAILED
    # The "broken" hook fails, but "ko" still runs.
    [(job, item)] = RECORDED
    assert job == "ko"
    assert item.vars["failed_job"] == "boom"
    assert item.vars["error"] == "RuntimeError: boom"
    [run] = state.runs()
    assert (run.status, run.job, run.error) == (Status.FAILED, "boom", "RuntimeError: boom")
    assert (config.scheduler.work_dir / str(run.id)).is_dir()  # kept for debugging


def test_data_must_stay_json(make_config: Callable[..., Config], inbox: Path) -> None:
    status, state = _run(make_config(pipeline(jobs='job "j" { plugin = "test_bad_data" }')), inbox)
    assert status == Status.FAILED
    assert "ValidationError" in (state.runs()[0].error or "")


def test_default_values_are_rendered_too(
    make_config: Callable[..., Config], inbox: Path, caplog: pytest.LogCaptureFixture
) -> None:
    config = make_config(pipeline(jobs='job "j" { plugin = "log" }'))  # message = "{path}"
    with caplog.at_level(logging.INFO):
        status, _ = _run(config, inbox)
    assert status is Status.SUCCESS
    assert str(inbox / "invoice_acme.csv") in caplog.text
    assert "{path}" not in caplog.text
