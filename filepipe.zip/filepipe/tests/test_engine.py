import logging
import os
import sqlite3
import threading
import time
from collections.abc import Callable
from pathlib import Path

import pytest
from conftest import RELEASE, pipeline

from filepipe.engine.config import Config
from filepipe.engine.db import State
from filepipe.engine.engine import Engine
from filepipe.engine.models import FileVersion, Status
from filepipe.engine.scanner import match_files


def _once(config: Config) -> list[Status]:
    return sorted(Engine(config, State(config.scheduler.state_db)).run_once())


def _statuses(config: Config) -> list[tuple[str, str, Status]]:
    runs = State(config.scheduler.state_db).runs()
    return sorted((r.pipeline, r.path.name, r.status) for r in runs)


def test_a_file_runs_every_matching_pipeline_once(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    config = make_config(
        pipeline("invoices", pattern="^invoice_"),
        pipeline("audit", pattern="\\\\.csv$"),
        pipeline("texte", pattern="\\\\.txt$"),
    )
    for name in ("invoice_1.csv", "other.csv", "notes.txt", "image.png"):
        (inbox / name).write_text("x")

    assert _once(config) == [Status.SUCCESS] * 4
    assert _statuses(config) == [
        ("audit", "invoice_1.csv", Status.SUCCESS),
        ("audit", "other.csv", Status.SUCCESS),
        ("invoices", "invoice_1.csv", Status.SUCCESS),
        ("texte", "notes.txt", Status.SUCCESS),
    ]
    assert _once(config) == []  # already processed


def test_a_modified_file_is_processed_again(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    config = make_config(pipeline())
    path = inbox / "a.csv"
    path.write_text("v1")
    assert _once(config) == [Status.SUCCESS]
    path.write_text("version 2")
    assert _once(config) == [Status.SUCCESS]


def test_start_mode_new_only_processes_files_that_appear_after_startup(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    old = inbox / "old.csv"
    old.write_text("x")
    config = make_config(pipeline(start_mode="new"))
    engine = Engine(config, State(config.scheduler.state_db))
    engine.start()
    assert engine.cycle() == []

    (inbox / "new.csv").write_text("x")
    assert engine.cycle() == [Status.SUCCESS]
    old.write_text("modified")  # a new version is a new file
    assert engine.cycle() == [Status.SUCCESS]
    assert _statuses(config) == [("p", "new.csv", Status.SUCCESS), ("p", "old.csv", Status.SUCCESS)]


def test_start_mode_is_applied_at_every_start(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    (inbox / "a.csv").write_text("x")
    assert _once(make_config(pipeline(start_mode="new"))) == []
    assert _once(make_config(pipeline(start_mode="all"))) == [Status.SUCCESS]  # nothing stored
    assert _once(make_config(pipeline(start_mode="all"))) == []  # already processed


def test_interrupted_runs_are_not_restarted(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    (inbox / "a.csv").write_text("x")
    config = make_config(pipeline())
    state = State(config.scheduler.state_db)
    state.start_run("p", next(match_files(config.pipelines[0].watch)))  # simulated crash

    assert _once(config) == []
    assert _statuses(config) == [("p", "a.csv", Status.INTERRUPTED)]

    State(config.scheduler.state_db).forget(status=Status.INTERRUPTED)
    assert _once(config) == [Status.SUCCESS]


def test_settle_waits_for_a_stable_file(make_config: Callable[..., Config], inbox: Path) -> None:
    now = [0.0]
    config = make_config(pipeline(settle="30s"))
    engine = Engine(config, State(config.scheduler.state_db), clock=lambda: now[0])
    engine.start()
    path = inbox / "a.csv"
    path.write_text("start")

    assert engine.cycle() == []
    now[0] = 20
    path.write_text("start and more")  # the file changes: the delay starts again
    assert engine.cycle() == []
    now[0] = 45
    assert engine.cycle() == []
    now[0] = 51
    assert engine.cycle() == [Status.SUCCESS]


def test_stop_waits_then_marks_running_runs_interrupted(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    (inbox / "a.csv").write_text("x")
    config = make_config(pipeline(jobs='job "slow" { plugin = "test_block" }'))
    state = State(config.scheduler.state_db)
    engine = Engine(config, state)
    result: list[bool] = []
    thread = threading.Thread(target=lambda: result.append(engine.run_forever()))
    thread.start()
    deadline = time.monotonic() + 5
    while not state.runs(status=Status.RUNNING) and time.monotonic() < deadline:
        time.sleep(0.01)

    engine.stopping.set()
    thread.join(5)

    assert result == [False]  # shutdown_timeout (1 s) exceeded
    assert state.runs()[0].status == Status.INTERRUPTED
    RELEASE.set()


def test_files_in_subdirectories_need_recursive(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    (inbox / "sub").mkdir()
    (inbox / "sub" / "a.csv").write_text("x")
    assert _once(make_config(pipeline())) == []
    recursive = pipeline(name="r").replace("settle", "recursive = true\n    settle")
    assert _once(make_config(recursive)) == [Status.SUCCESS]


def test_statuses_are_enum_members(make_config: Callable[..., Config], inbox: Path) -> None:
    (inbox / "a.csv").write_text("x")
    config = make_config(pipeline())
    [status] = _once(config)
    assert status is Status.SUCCESS
    assert State(config.scheduler.state_db).runs()[0].status is Status.SUCCESS


def test_a_file_under_two_watched_paths_runs_once(
    make_config: Callable[..., Config], inbox: Path
) -> None:
    (inbox / "sub").mkdir()
    (inbox / "sub" / "a.csv").write_text("x")
    hcl = pipeline().replace(
        'paths    = ["inbox"]', 'paths    = ["inbox", "inbox/sub", "inbox/sub"]'
    )
    hcl = hcl.replace("settle", "recursive = true\n    settle")
    assert _once(make_config(hcl)) == [Status.SUCCESS]


def test_a_file_name_that_is_not_utf8_is_skipped(
    make_config: Callable[..., Config], inbox: Path, caplog: pytest.LogCaptureFixture
) -> None:
    (inbox / "ok.csv").write_text("x")
    os.close(os.open(os.fsencode(inbox) + b"/invoice\xe9.csv", os.O_CREAT | os.O_WRONLY))
    config = make_config(pipeline())
    with caplog.at_level(logging.WARNING):
        assert _once(config) == [Status.SUCCESS]
    assert "not valid UTF-8" in caplog.text


def test_an_internal_error_is_logged_without_hiding_the_other_runs(
    make_config: Callable[..., Config],
    inbox: Path,
    caplog: pytest.LogCaptureFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    (inbox / "a.csv").write_text("x")
    (inbox / "b.csv").write_text("x")
    config = make_config(pipeline())
    state = State(config.scheduler.state_db)
    start_run = state.start_run

    def flaky_start_run(pipeline: str, version: FileVersion) -> int:
        if version.path.name == "a.csv":
            raise sqlite3.OperationalError("disk I/O error")
        return start_run(pipeline, version)

    monkeypatch.setattr(state, "start_run", flaky_start_run)
    assert Engine(config, state).run_once() == [Status.SUCCESS]
    assert "internal error" in caplog.text


def test_stop_between_two_cycles_is_quick(make_config: Callable[..., Config]) -> None:
    config = make_config(pipeline())  # poll_interval: 10 s by default
    engine = Engine(config, State(config.scheduler.state_db))
    result: list[bool] = []
    thread = threading.Thread(target=lambda: result.append(engine.run_forever()))
    thread.start()
    time.sleep(0.3)
    engine.stopping.set()
    thread.join(2)
    assert result == [True]
