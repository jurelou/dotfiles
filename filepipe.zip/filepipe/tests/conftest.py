"""Shared helpers: test plugins, plugin fixtures, HCL configs."""

import json
import logging
import threading
from collections.abc import Callable, Iterator
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import pytest

from filepipe.engine.config import Config, load_config
from filepipe.engine.models import Context, Item, Skip
from filepipe.engine.plugin import Plugin, PluginParams, register

# --- test plugins ----------------------------------------------------------------------------

RECORDED: list[tuple[str, Item]] = []  # (job, item received), in execution order
RELEASE = threading.Event()  # releases the test_block plugin


class SetParams(PluginParams):
    key: str = "x"
    value: str = "1"


@register("test_record")
class Record(Plugin[PluginParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        RECORDED.append((ctx.job, item))
        return item


@register("test_set")
class SetData(Plugin[SetParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        return item.model_copy(update={"data": {**item.data, self.params.key: self.params.value}})


@register("test_fail")
class Fail(Plugin[PluginParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        raise RuntimeError("boom")


@register("test_skip")
class SkipIt(Plugin[PluginParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        raise Skip("not for me")


@register("test_bad_data")
class BadData(Plugin[PluginParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        return item.model_copy(update={"data": {"obj": object()}})


@register("test_block")
class Block(Plugin[PluginParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        RELEASE.wait(10)
        return item


@pytest.fixture(autouse=True)
def _reset() -> None:
    RECORDED.clear()
    RELEASE.clear()


# --- plugin fixtures ------------------------------------------------------------------------


@pytest.fixture
def item(tmp_path: Path) -> Item:
    source = tmp_path / "invoice.csv"
    source.write_text("a;b\n1;2\n")
    return Item(source=source, files=(source,), vars={"name": source.name})


@pytest.fixture
def ctx(tmp_path: Path) -> Context:
    workdir = tmp_path / "work"
    workdir.mkdir()
    log = logging.LoggerAdapter(logging.getLogger("test"), {})
    return Context(
        run_id=7, pipeline="p", job="check", workdir=workdir, log=log, stopping=threading.Event()
    )


class RecordingServer(ThreadingHTTPServer):
    """Local HTTP server that records the JSON requests it receives."""

    def __init__(self) -> None:
        super().__init__(("127.0.0.1", 0), _RecordingHandler)
        self.requests: list[tuple[str, dict[str, str], Any]] = []  # path, headers, body
        self.status = 200

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.server_port}"


class _RecordingHandler(BaseHTTPRequestHandler):
    def do_POST(self) -> None:
        assert isinstance(self.server, RecordingServer)
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        self.server.requests.append((self.path, dict(self.headers), body))
        self.send_response(self.server.status)
        self.end_headers()

    def log_message(self, *args: Any) -> None:
        pass


@pytest.fixture
def http_server(monkeypatch: pytest.MonkeyPatch) -> Iterator[RecordingServer]:
    monkeypatch.setenv("no_proxy", "127.0.0.1")  # urllib must not use a proxy
    server = RecordingServer()
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield server
    server.shutdown()
    server.server_close()


# --- configs --------------------------------------------------------------------------------


def pipeline(
    name: str = "p",
    jobs: str = 'job "j" { plugin = "test_record" }',
    pattern: str = r"\\.csv$",
    start_mode: str = "all",
    settle: str = "0s",
    extra: str = "",
) -> str:
    """HCL pipeline block. `pattern` is written as is in the HCL (doubled backslashes)."""
    return f"""
pipeline "{name}" {{
  start_mode = "{start_mode}"
  watch {{
    paths    = ["inbox"]
    patterns = ["{pattern}"]
    settle   = "{settle}"
  }}
  {jobs}
  {extra}
}}
"""


@pytest.fixture
def inbox(tmp_path: Path) -> Path:
    path = tmp_path / "inbox"
    path.mkdir()
    return path


@pytest.fixture
def write_config(tmp_path: Path, inbox: Path) -> Callable[..., Path]:
    def write(*pipelines: str, scheduler: str = "") -> Path:
        path = tmp_path / "config.hcl"
        header = (
            'scheduler {\n  state_db = "state.db"\n  work_dir = "work"\n'
            f'  shutdown_timeout = "1s"\n  {scheduler}\n}}\n'
        )
        path.write_text(header + "".join(pipelines), encoding="utf-8")
        return path

    return write


@pytest.fixture
def make_config(write_config: Callable[..., Path]) -> Callable[..., Config]:
    def make(*pipelines: str, scheduler: str = "") -> Config:
        return load_config(write_config(*pipelines, scheduler=scheduler))

    return make
