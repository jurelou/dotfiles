import urllib.error

import pytest
from conftest import RecordingServer

from filepipe.engine.models import Context, Item
from filepipe.plugins.webhook import Webhook, WebhookParams


def test_sends_the_item_by_default(item: Item, ctx: Context, http_server: RecordingServer) -> None:
    params = WebhookParams(url=f"{http_server.url}/hook", headers={"X-Token": "abc"})
    assert Webhook(params).run(item, ctx) == item

    [(path, headers, body)] = http_server.requests
    assert path == "/hook"
    assert headers["X-Token"] == "abc"
    assert body["source"] == str(item.source)
    assert body["vars"] == item.vars


def test_sends_the_given_body(item: Item, ctx: Context, http_server: RecordingServer) -> None:
    params = WebhookParams(url=f"{http_server.url}/hook", body={"file": "a.csv", "n": 2})
    Webhook(params).run(item, ctx)
    assert http_server.requests[0][2] == {"file": "a.csv", "n": 2}


def test_http_error_fails_the_job(item: Item, ctx: Context, http_server: RecordingServer) -> None:
    http_server.status = 503
    with pytest.raises(urllib.error.HTTPError):
        Webhook(WebhookParams(url=f"{http_server.url}/hook")).run(item, ctx)
