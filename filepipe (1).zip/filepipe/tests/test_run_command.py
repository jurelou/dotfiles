import os
import subprocess
import sys
from typing import Any

import pytest

from filepipe.engine.models import Context, Item, Skip
from filepipe.plugins.run_command import Exec, ExecParams


def _python(code: str, item: Item, ctx: Context, **params: Any) -> Item:
    plugin = Exec(ExecParams(command=sys.executable, args=["-c", code], **params))
    return plugin.run(item, ctx)


def test_text_output_goes_to_data(item: Item, ctx: Context) -> None:
    result = _python("print('  hello  ')", item, ctx, output="text")
    assert result.data == {"check": "hello"}


def test_output_is_ignored_by_default(item: Item, ctx: Context) -> None:
    assert _python("print('hello')", item, ctx) == item


def test_receives_item_on_stdin_and_runs_in_workdir(item: Item, ctx: Context) -> None:
    code = (
        "import json, os, sys; item = json.load(sys.stdin);"
        "print(item['vars']['name'], os.getcwd(), os.environ['FILEPIPE_RUN_ID'])"
    )
    result = _python(code, item, ctx, output="text")
    assert result.data["check"] == f"invoice.csv {ctx.workdir} 7"


def test_json_output_updates_files_and_data(item: Item, ctx: Context) -> None:
    code = (
        "import json; open('out.txt', 'w').write('x');"
        "print(json.dumps({'files': ['out.txt'], 'data': {'lines': 2}}))"
    )
    result = _python(code, item, ctx, output="json")
    assert result.files == (ctx.workdir / "out.txt",)
    assert result.data == {"lines": 2}


def test_arguments_are_passed_without_a_shell(item: Item, ctx: Context) -> None:
    plugin = Exec(
        ExecParams(
            command=sys.executable,
            args=["-c", "import sys; print(sys.argv[1:])", "a b", "$HOME", ";"],
            output="text",
        )
    )
    assert plugin.run(item, ctx).data["check"] == "['a b', '$HOME', ';']"


def test_exit_code_99_skips(item: Item, ctx: Context) -> None:
    with pytest.raises(Skip, match="empty"):
        _python("print('empty'); raise SystemExit(99)", item, ctx)


def test_other_exit_codes_fail(item: Item, ctx: Context) -> None:
    with pytest.raises(RuntimeError, match="exit code 3"):
        _python("raise SystemExit(3)", item, ctx)


def test_timeout(item: Item, ctx: Context) -> None:
    with pytest.raises(TimeoutError, match=r"timed out after 0\.2 s"):
        _python("import time; time.sleep(5)", item, ctx, timeout="200ms")


def test_missing_command(item: Item, ctx: Context) -> None:
    with pytest.raises(FileNotFoundError):
        Exec(ExecParams(command="/nonexistent/cmd")).run(item, ctx)


def test_binary_output_does_not_fail(item: Item, ctx: Context) -> None:
    code = (
        "import sys; sys.stdout.buffer.write(bytes(range(256))); sys.stderr.buffer.write(b'\\xff')"
    )
    assert _python(code, item, ctx) == item


def test_timeout_also_kills_the_processes_started_by_the_command(item: Item, ctx: Context) -> None:
    seconds = str(1000 + os.getpid() % 1000)  # a unique `sleep` to look for
    plugin = Exec(
        ExecParams(command="bash", args=["-c", f"sleep {seconds}; echo done"], timeout=0.3)
    )
    with pytest.raises(TimeoutError):
        plugin.run(item, ctx)
    left = subprocess.run(["pgrep", "-x", "-f", f"sleep {seconds}"], capture_output=True)
    assert left.stdout == b""
