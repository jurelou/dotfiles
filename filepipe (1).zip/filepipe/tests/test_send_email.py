import smtplib
from email.message import EmailMessage
from typing import Any

import pytest
from pydantic import ValidationError

from filepipe.engine.models import Context, Item
from filepipe.plugins.send_email import Email, EmailParams


class FakeSMTP:
    """Records what the plugin does instead of talking to a server."""

    calls: list[str]
    sent: list[EmailMessage]

    def __init__(self, host: str, port: int, timeout: float) -> None:
        self.calls.append(f"connect {host}:{port}")

    def __enter__(self) -> "FakeSMTP":
        return self

    def __exit__(self, *exc_info: Any) -> None:
        pass

    def starttls(self) -> None:
        self.calls.append("starttls")

    def login(self, user: str, password: str) -> None:
        self.calls.append(f"login {user} {password}")

    def send_message(self, message: EmailMessage) -> None:
        self.sent.append(message)


@pytest.fixture
def smtp(monkeypatch: pytest.MonkeyPatch) -> type[FakeSMTP]:
    FakeSMTP.calls, FakeSMTP.sent = [], []
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    return FakeSMTP


def test_sends_the_email(
    item: Item, ctx: Context, smtp: type[FakeSMTP], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SMTP_PASSWORD", "s3cret")
    failed = item.model_copy(update={"vars": {"failed_job": "export", "error": "OSError: full"}})
    params = EmailParams(
        host="smtp.example.com",
        user="filepipe",
        password_env="SMTP_PASSWORD",
        sender="filepipe@example.com",
        to=["ops@example.com", "dev@example.com"],
        subject="export failed on a\nb.csv",
    )
    Email(params).run(failed, ctx)

    assert smtp.calls == ["connect smtp.example.com:587", "starttls", "login filepipe s3cret"]
    [message] = smtp.sent
    assert message["Subject"] == "export failed on a b.csv"  # a line break would be refused
    assert message["To"] == "ops@example.com, dev@example.com"
    assert "Failed job: export" in message.get_content()
    assert "Error: OSError: full" in message.get_content()


def test_user_without_password_env_is_a_config_error() -> None:
    with pytest.raises(ValidationError, match="password_env is required"):
        EmailParams(host="h", user="u", sender="s", to=["t"], subject="x")


def test_missing_password_variable_fails_the_job(
    item: Item, ctx: Context, smtp: type[FakeSMTP], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("SMTP_PASSWORD", raising=False)
    params = EmailParams(
        host="h", user="u", password_env="SMTP_PASSWORD", sender="s", to=["t"], subject="x"
    )
    with pytest.raises(RuntimeError, match="SMTP_PASSWORD is not set"):
        Email(params).run(item, ctx)
