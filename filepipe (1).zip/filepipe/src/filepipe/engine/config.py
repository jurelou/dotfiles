"""HCL configuration loading, fully validated at load time.

This is the only module that knows about python-hcl2: the rest of the code only sees models.
"""

import re
from collections.abc import Iterator
from pathlib import Path
from typing import Annotated, Any, Literal, Self

import hcl2
from pydantic import (
    AfterValidator,
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    ValidationInfo,
    model_validator,
)

from filepipe.engine import template
from filepipe.engine.models import BUILTIN_VARS, FAILURE_VARS, Duration
from filepipe.engine.plugin import get_plugin

# Without these options, python-hcl2 8.x returns strings with their surrounding quotes, and
# heredocs (<<EOT ... EOT) with their markers.
_HCL_OPTIONS = hcl2.SerializationOptions(
    strip_string_quotes=True, explicit_blocks=False, with_comments=False, preserve_heredocs=False
)


class ConfigError(ValueError):
    """Unreadable or invalid configuration."""


def _absolute(path: Path, info: ValidationInfo) -> Path:
    """A relative path starts from the directory of the configuration file."""
    base: Path = (info.context or {}).get("base", Path.cwd())
    return (base / path).absolute()


AbsolutePath = Annotated[Path, AfterValidator(_absolute)]


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class SchedulerConfig(_Model):
    poll_interval: Annotated[Duration, Field(gt=0)] = 10
    workers: int = Field(default=4, ge=1)
    state_db: AbsolutePath = Path("/var/lib/filepipe/state.db")
    work_dir: AbsolutePath = Path("/var/lib/filepipe/work")
    shutdown_timeout: Duration = 300
    log_file: AbsolutePath | None = None  # logs go to stdout, and to this file when set


class WatchConfig(_Model):
    paths: list[AbsolutePath] = Field(min_length=1)
    patterns: list[re.Pattern[str]] = Field(min_length=1)
    recursive: bool = False
    settle: Duration = 30


class JobConfig(_Model):
    name: str
    plugin: str
    params: dict[str, Any] = {}  # kept raw: templates are rendered at run time

    @model_validator(mode="after")
    def _check_params(self) -> Self:
        params_model = get_plugin(self.plugin).Params
        try:
            params_model.model_validate(self.params)
        except ValidationError as exc:
            errors = "; ".join(f"{_dotted(e['loc'])}: {e['msg']}" for e in exc.errors())
            raise ValueError(f"invalid params for {self.plugin}: {errors}") from None
        return self


class PipelineConfig(_Model):
    name: str
    start_mode: Literal["all", "new"]
    watch: WatchConfig
    jobs: list[JobConfig] = Field(min_length=1)
    on_success: list[JobConfig] = []
    on_failure: list[JobConfig] = []

    @model_validator(mode="after")
    def _check(self) -> Self:
        names = [job.name for job in (*self.jobs, *self.on_success, *self.on_failure)]
        if duplicates := sorted({n for n in names if names.count(n) > 1}):
            raise ValueError(f"duplicate job names: {', '.join(duplicates)}")

        # A group can only be used if it exists in every pattern.
        groups = set.intersection(*(set(p.groupindex) for p in self.watch.patterns))
        if reserved := sorted(groups & BUILTIN_VARS):
            raise ValueError(f"reserved regex group names: {', '.join(reserved)}")
        for jobs, allowed in (
            (self.jobs, BUILTIN_VARS | groups),
            (self.on_success, BUILTIN_VARS | groups),
            (self.on_failure, BUILTIN_VARS | groups | FAILURE_VARS),
        ):
            for job in jobs:
                used = {n for n in template.names(job.params) if not n.startswith("data.")}
                if unknown := sorted(used - allowed):
                    raise ValueError(f"job {job.name}: unknown variable(s) {unknown}")
        return self


class Config(_Model):
    scheduler: SchedulerConfig = SchedulerConfig()
    pipelines: list[PipelineConfig] = Field(min_length=1)

    @model_validator(mode="after")
    def _check(self) -> Self:
        names = [p.name for p in self.pipelines]
        if duplicates := sorted({n for n in names if names.count(n) > 1}):
            raise ValueError(f"duplicate pipeline names: {', '.join(duplicates)}")
        return self


def load_config(path: Path) -> Config:
    try:
        with path.open(encoding="utf-8") as f:
            raw = hcl2.load(f, serialization_options=_HCL_OPTIONS)
    except OSError as exc:
        raise ConfigError(f"{path}: {exc.strerror}") from None
    except Exception as exc:  # python-hcl2 raises several kinds of syntax errors
        raise ConfigError(f"{path}: invalid HCL syntax\n{exc}") from None
    data = _normalize(raw)
    try:
        return Config.model_validate(data, context={"base": path.parent})
    except ValidationError as exc:
        lines = [f"  {_named_loc(e['loc'], data)}: {e['msg']}" for e in exc.errors()]
        raise ConfigError(f"{path}: invalid configuration\n" + "\n".join(lines)) from None


# --- HCL -> dictionary expected by the models -----------------------------------------------


def _normalize(raw: dict[str, Any]) -> dict[str, Any]:
    out = dict(raw)
    if "scheduler" in out:
        out["scheduler"] = _single(out["scheduler"], "scheduler")
    out["pipelines"] = [_pipeline(name, body) for name, body in _labeled(out.pop("pipeline", []))]
    return out


def _pipeline(name: str, body: dict[str, Any]) -> dict[str, Any]:
    out = dict(body, name=name)
    if "watch" in out:
        out["watch"] = _single(out["watch"], f"pipeline {name}: watch")
    out["jobs"] = _jobs(out.pop("job", []))
    for hook in ("on_success", "on_failure"):
        if hook in out:
            hook_body = dict(_single(out[hook], f"pipeline {name}: {hook}"))
            out[hook] = _jobs(hook_body.pop("job", []))
            if hook_body:
                raise ConfigError(f"pipeline {name}: {hook} only accepts job blocks")
    return out


def _jobs(blocks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [dict(body, name=name) for name, body in _labeled(blocks)]


def _single(blocks: list[dict[str, Any]], what: str) -> dict[str, Any]:
    if len(blocks) != 1:
        raise ConfigError(f"{what}: expected a single block, found {len(blocks)}")
    return blocks[0]


def _labeled(blocks: list[dict[str, Any]]) -> Iterator[tuple[str, dict[str, Any]]]:
    """Labeled blocks (`job "x" { ... }`), returned by python-hcl2 as {"x": {...}}."""
    for block in blocks:
        (name, body), *rest = block.items()
        if rest or not isinstance(body, dict):
            raise ConfigError(f"block without a label: {sorted(block)}")
        if "name" in body:
            raise ConfigError(f"{name}: no `name` attribute, the label is the name")
        yield name, body


# --- Error messages -------------------------------------------------------------------------


def _dotted(loc: tuple[int | str, ...]) -> str:
    return ".".join(str(part) for part in loc)


def _named_loc(loc: tuple[int | str, ...], data: Any) -> str:
    """Replace list indexes with the name of the items: pipelines.invoices.jobs.export."""
    parts = []
    for key in loc:
        named = isinstance(key, int) and isinstance(data, list) and key < len(data)
        if named and isinstance(data[key], dict) and "name" in data[key]:
            parts.append(str(data[key]["name"]))
        else:
            parts.append(str(key))
        try:
            data = data[key]
        except (KeyError, IndexError, TypeError):
            data = None
    return ".".join(parts)
