"""Run an external command with its arguments, without a shell.

- The command receives the Item as JSON on stdin and runs in the work directory of the run.
- It also gets the FILEPIPE_RUN_ID and FILEPIPE_WORKDIR environment variables.
- Exit code 0: success; 99: Skip; any other code: failure.
- On timeout, the command and every process it started are killed.
- `output` decides what happens to stdout:
    "none": ignored;
    "text": stored in data[<job name>];
    "json": an object {"files": [...], "data": {...}} that updates the Item.
      Relative paths in "files" start from the work directory.
"""

import os
import shlex
import signal
import subprocess
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, JsonValue

from filepipe.engine.models import Context, Duration, Item, Skip
from filepipe.engine.plugin import Plugin, PluginParams, register

SKIP_EXIT_CODE = 99


class ExecParams(PluginParams):
    command: str
    args: list[str] = []
    timeout: Duration | None = None
    env: dict[str, str] = {}
    output: Literal["none", "text", "json"] = "none"


class ExecOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    files: list[Path] | None = None
    data: dict[str, JsonValue] = {}


@register("exec")
class Exec(Plugin[ExecParams]):
    def run(self, item: Item, ctx: Context) -> Item:
        p = self.params
        argv = [p.command, *p.args]
        env = {
            **os.environ,
            **p.env,
            "FILEPIPE_RUN_ID": str(ctx.run_id),
            "FILEPIPE_WORKDIR": str(ctx.workdir),
        }
        ctx.log.info("running %s", shlex.join(argv))
        with subprocess.Popen(
            argv,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="replace",  # stdout may be binary: only "text" and "json" read it
            cwd=ctx.workdir,
            env=env,
            start_new_session=True,  # its own process group, to kill it as a whole
        ) as proc:
            try:
                stdout, stderr = proc.communicate(item.model_dump_json(), timeout=p.timeout)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
                raise TimeoutError(f"{p.command}: timed out after {p.timeout:g} s") from None
        for line in stderr.splitlines():
            ctx.log.info("stderr: %s", line)
        if proc.returncode == SKIP_EXIT_CODE:
            raise Skip(stdout.strip() or f"exit code {SKIP_EXIT_CODE}")
        if proc.returncode != 0:
            raise RuntimeError(f"{p.command}: exit code {proc.returncode}")
        return self._apply_output(item, stdout, ctx)

    def _apply_output(self, item: Item, stdout: str, ctx: Context) -> Item:
        if self.params.output == "text":
            return item.model_copy(update={"data": {**item.data, ctx.job: stdout.strip()}})
        if self.params.output == "json":
            output = ExecOutput.model_validate_json(stdout)
            update: dict[str, Any] = {"data": {**item.data, **output.data}}
            if output.files is not None:
                update["files"] = tuple(ctx.workdir / f for f in output.files)
            return item.model_copy(update=update)
        return item
