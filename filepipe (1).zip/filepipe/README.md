# filepipe

A Python daemon that watches directories and, for every new file whose name matches a regex,
runs the jobs of the pipelines configured in HCL, in order.

- A file that matches several pipelines runs all of them, in parallel.
- The source file is never modified: SQLite remembers what has been processed.
- Nothing is retried automatically: a failure triggers `on_failure`, reprocessing is manual.

## Development

```sh
uv sync                                           # creates .venv with the dependencies
uv run filepipe -c examples/config.hcl validate   # validates the example
uv run pytest                                     # tests
uv run ruff check && uv run ruff format --check   # lint and format
uv run mypy src                                   # strict typing
```

## Code layout

```
src/filepipe/
├── cli.py            click commands
├── engine/
│   ├── config.py     HCL loading and validation (the only module that imports python-hcl2)
│   ├── models.py     FileVersion, Item, Context, Skip, Duration
│   ├── plugin.py     Plugin base class and registry
│   ├── template.py   {variable} rendering
│   ├── scanner.py    regex matching, start_mode and file stability
│   ├── db.py         SQLite
│   ├── runner.py     execution of a run
│   └── engine.py     Engine: cycles, thread pool, clean shutdown
└── plugins/          log, copy_files, run_command, webhook, send_email, mattermost
```

## How the daemon works

The daemon runs in cycles. Each cycle scans the watched directories, starts every ready file
that is not in the database yet (in parallel, up to `workers`), waits for all these runs to
finish, then sleeps `poll_interval` before the next scan. A long job therefore delays the
detection of new files until the end of its cycle.

## Configuration

See [`examples/config.hcl`](examples/config.hcl). Things to know:

- Regexes are HCL strings: backslashes are doubled (`"\\d{8}"`).
- Multi-line texts (a message, an email body) can use heredocs: `<<EOT ... EOT`.
- Regexes are applied with `re.search` to the path relative to the watched directory (the file
  name when `recursive = false`).
- A relative path in `scheduler` or `watch` starts from the directory of the configuration file.
- A relative path in the `params` of a job starts from the work directory of the run.
- `settle`: how long a file must stay unchanged before it is processed.
- `log_file` (optional): the logs always go to stdout (journald under systemd) and, when set, also
  to this file, with timestamps. It is rotated at 10 MB, keeping 5 old files.
- `start_mode` applies at every start. `all` processes the files already there that are not in
  the database yet. `new` ignores every file present at startup (until it changes) and only
  processes the files that appear afterwards: files that arrive while the daemon is stopped are
  ignored, and `run-once` processes nothing.
- The whole configuration is validated at startup: an unknown key or plugin stops the startup with
  a message that points at the faulty key.

### Templates

In `params`, `{name}` is replaced at run time:

| Variable | Content |
| --- | --- |
| named groups of the regexes | `{client}`, `{date}`... |
| `{path}`, `{name}`, `{stem}`, `{suffix}`, `{dir}` | the source file |
| `{pipeline}`, `{run_id}` | the run |
| `{data.key}` | a value produced by a previous job |
| `{failed_job}`, `{error}` | only in `on_failure` |

## Built-in plugins

| Plugin | Role | Params |
| --- | --- | --- |
| `log` | writes a message to the log | `message`, `level` |
| `copy` | copies the current files to a directory | `dest` |
| `exec` | runs a command with its arguments | `command`, `args`, `timeout`, `env`, `output` |
| `webhook` | sends a JSON POST | `url`, `method`, `body`, `headers`, `timeout` |
| `email` | sends an email over SMTP | `host`, `port`, `tls`, `user`, `password_env`, `sender`, `to`, `subject`, `body` |
| `mattermost` | posts a message through an incoming webhook | `message`, `webhook_url`, `channel`, `api_key`, `timeout` |

### The `mattermost` plugin

`channel` is the channel name (`town-square`, not `Town Square`); without it, the message goes to
the default channel of the webhook. Mattermost does not check any API key on incoming webhooks:
the webhook URL itself is the secret. When `api_key` is set, it is sent as
`Authorization: Bearer <key>`, for example for a reverse proxy in front of Mattermost.

### The `exec` contract

- The command runs without a shell: `command` is the executable, `args` the list of its arguments.
- It receives the Item as JSON on stdin and runs in the work directory of the run, with the
  `FILEPIPE_RUN_ID` and `FILEPIPE_WORKDIR` environment variables.
- Exit code 0: success; 99: the chain stops normally (`Skip`); anything else: failure.
- After `timeout`, the command and every process it started are killed.
- `output = "text"` stores stdout in `data.<job name>`; `output = "json"` expects an object
  `{"files": [...], "data": {...}}` that updates the Item.

## Writing a plugin

```python
from filepipe.engine.models import Context, Item, Skip
from filepipe.engine.plugin import Plugin, PluginParams, register


class MinSizeParams(PluginParams):
    min_bytes: int


@register("min_size")
class MinSize(Plugin[MinSizeParams]):  # the generic argument gives the params model
    def run(self, item: Item, ctx: Context) -> Item:
        size = item.source.stat().st_size
        if size < self.params.min_bytes:
            raise Skip(f"{size} bytes")
        return item.model_copy(update={"data": {**item.data, "size": size}})
```

Then import it in `src/filepipe/plugins/__init__.py`. The rules:

- return a new `Item` with `model_copy(update=...)`, never modify the one you receive;
- never modify or move `item.source`: other pipelines may use it;
- `data` must stay JSON-serializable;
- `raise Skip("reason")` stops the chain without an error; any other exception is a failure.

## Deployment

Requires [uv](https://docs.astral.sh/uv/) on the server.

```sh
sudo useradd --system --home /opt/filepipe filepipe
sudo git clone <repository> /opt/filepipe && cd /opt/filepipe
sudo uv sync --frozen --no-dev            # installs into /opt/filepipe/.venv
sudo install -D -m 640 examples/config.hcl /etc/filepipe/config.hcl
sudo cp deploy/filepipe.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now filepipe
```

Adjust `ReadWritePaths` in the unit to the directories the pipelines write to.

## Operations

```sh
journalctl -u filepipe -f                                  # logs (or tail -f the log_file)
filepipe -c /etc/filepipe/config.hcl status                # runs per status, failures
filepipe -c /etc/filepipe/config.hcl forget --status failed --pipeline invoices   # reprocess
filepipe -c /etc/filepipe/config.hcl validate && sudo systemctl restart filepipe   # new config
```

A stop waits for the running runs up to `shutdown_timeout`. Beyond that, or after a crash, they
become `interrupted` and are not restarted: `forget --status interrupted` puts them back in play.
